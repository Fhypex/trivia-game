using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestionsManager : Singleton<QuestionsManager>
{
    public QuestionUI Question;
    private GameManager _gameManager;

    public string CategoryName;

    private void OnEnable(){
        _gameManager = GameManager.Instance;

        LoadNextQuestion();
    }


    void LoadNextQuestion(){
        var newQuestion = _gameManager.GetQuestionForCategory(CategoryName);
        if(newQuestion != null){
            Question.PopulateQuestion(newQuestion);
        }
    }
}